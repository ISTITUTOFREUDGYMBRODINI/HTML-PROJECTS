function addToCart(product) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
}

function renderCart() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let cartDiv = document.getElementById('cart');
    cartDiv.innerHTML = '';
    cart.forEach(product => {
        let productDiv = document.createElement('div');
        productDiv.textContent = product;
        cartDiv.appendChild(productDiv);
    });
}

window.onload = renderCart;